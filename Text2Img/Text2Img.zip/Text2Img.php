<?php
// 设置内容类型为图片
header("Content-Type: image/png; charset=UTF-8");

// 获取传入的文本参数
$text = isset($_GET['text']) ? $_GET['text'] : '请输入文本';

// 图片的宽度和初始高度
$width = 400;
$initialHeight = 200;  // 初始图片高度
$minHeight = 100;      // 设置最小高度

// 创建一个空白图片
$image = imagecreatetruecolor($width, $initialHeight);

// 分配颜色
$white = imagecolorallocate($image, 255, 255, 255);  // 白色
$black = imagecolorallocate($image, 0, 0, 0);        // 黑色

// 填充背景为白色
imagefilledrectangle($image, 0, 0, $width, $initialHeight, $white);

// 设置字体路径
$font_regular = __DIR__ . '/font/LXGWWenKaiMono-Regular.ttf';  // 中文和英文字体
$font_emoji = __DIR__ . '/font/NotoEmoji-VariableFont_wght.ttf';    // Emoji 字体

// 设定字体大小
$fontSize = 20;

// 自动换行函数，根据图片宽度调整文本
function wrapText($fontSize, $font, $text, $width) {
    $words = explode("\n", wordwrap($text, 50, "\n"));  // 通过换行符分割文本，50为字数限制
    $wrappedText = [];
    foreach ($words as $word) {
        $textBox = imagettfbbox($fontSize, 0, $font, $word);
        $textWidth = $textBox[2] - $textBox[0];
        if ($textWidth > $width) {
            // 如果当前行的宽度超过图片宽度，进行手动分行
            $wrappedText[] = wordwrap($word, floor($width / ($fontSize * 0.6)), "\n", true);
        } else {
            $wrappedText[] = $word;
        }
    }
    return implode("\n", $wrappedText);
}

// 包装文本为多行
$wrappedText = wrapText($fontSize, $font_regular, $text, $width - 40);  // 减去40是为了给左右边距留出空间

// 计算文本的边界框尺寸
$lines = explode("\n", $wrappedText);
$lineHeight = $fontSize + 10;  // 增加行间距

// 动态调整图片高度，根据行数适当增加高度，但不低于最小高度
$totalTextHeight = count($lines) * $lineHeight;
if ($totalTextHeight + 40 < $minHeight) {
    $height = $minHeight;  // 使用最小高度
} else {
    $height = $totalTextHeight + 40;  // 增加上下边距，避免文本过于靠近边框
}
$image = imagecreatetruecolor($width, $height);
imagefilledrectangle($image, 0, 0, $width, $height, $white);

// 计算起始 y 坐标，使多行文本垂直居中，调整 5 像素
$y = ($height - $totalTextHeight) / 2 + $fontSize + 5;

// 绘制文本时判断字符类型
function drawText($image, $fontSize, $x, $y, $black, $font_regular, $font_emoji, $text) {
    for ($i = 0; $i < mb_strlen($text); $i++) {
        $char = mb_substr($text, $i, 1);

        // 判断字符是否是 Emoji
        if (preg_match('/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{2600}-\x{26FF}]/u', $char)) {
            $font = $font_emoji;  // 使用 Emoji 字体
        } else {
            $font = $font_regular;  // 使用常规字体
        }

        // 计算字符宽度
        $textBox = imagettfbbox($fontSize, 0, $font, $char);
        $charWidth = $textBox[2] - $textBox[0];

        // 绘制字符
        imagettftext($image, $fontSize, 0, $x, $y, $black, $font, $char);

        // 更新 x 坐标
        $x += $charWidth;
    }
}

// 绘制每一行文本到图片上
foreach ($lines as $line) {
    $textBox = imagettfbbox($fontSize, 0, $font_regular, $line);
    $textWidth = $textBox[2] - $textBox[0];
    $x = ($width - $textWidth) / 2;  // 水平居中

    drawText($image, $fontSize, $x, $y, $black, $font_regular, $font_emoji, $line);
    $y += $lineHeight;
}

// 输出图片
imagepng($image);

// 销毁图片资源
imagedestroy($image);
?>
