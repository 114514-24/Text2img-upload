<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>图片生成器</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            resize: vertical;
            min-height: 100px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .output {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }
        .output p {
            margin: 10px 0;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box; /* 确保边框和填充被包含在宽度内 */
        }
        .message {
            margin-top: 10px;
            color: green;
            font-size: 14px;
        }
        #preview {
            margin-top: 20px;
        }
        #preview img {
            max-width: 100%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>生成带有文字的图片链接</h2>

    <label for="text">输入要生成图片的文字：</label>
    <textarea id="text" placeholder="请输入文本"></textarea>

    <button onclick="generateLink()">生成图片链接</button>

    <div id="output" class="output" style="display:none;">
        <p>普通链接：</p>
        <input type="text" id="normalLink" readonly>

        <p>Markdown 格式链接：</p>
        <input type="text" id="markdownLink" readonly>

        <button onclick="copyLink()">一键复制普通链接</button>
        <button onclick="copyMarkdownLink()">一键复制 Markdown 链接</button>

        <div id="message" class="message" style="display: none;"></div>
    </div>

    <!-- 预览图片的区域 -->
    <div id="preview" style="display:none;">
        <h3>图片预览：</h3>
        <img id="previewImage" src="" alt="图片预览">
    </div>
</div>

<script>
    const baseUrl = "https://php.s.199577.xyz/Text2Img.php?text="; // 定义全局 URL 基础地址
    let typingTimer; // 计时器
    const doneTypingInterval = 1000; // 1秒延迟
    const textInput = document.getElementById('text');

    // 监听输入事件并进行延时操作
    textInput.addEventListener('input', () => {
        clearTimeout(typingTimer); // 如果用户继续输入，清除之前的计时器
        if (textInput.value) {
            typingTimer = setTimeout(showPreview, doneTypingInterval); // 停止输入1秒后显示预览
        }
    });

    // 生成链接的函数
    function generateLink() {
        const text = textInput.value;
        if (!text) return;

        const imgUrl = createImageUrl(text);

        // 设置普通链接和Markdown格式链接
        document.getElementById('normalLink').value = imgUrl;
        document.getElementById('markdownLink').value = `![${text.replace(/\n/g, ' ')}](${imgUrl})`;

        // 显示结果区域
        document.getElementById('output').style.display = 'block';
    }

    // 显示图片预览并自动生成链接
    function showPreview() {
        const text = textInput.value;
        if (!text) return;

        const imgUrl = createImageUrl(text);

        // 显示预览图片
        document.getElementById('previewImage').src = imgUrl;
        document.getElementById('preview').style.display = 'block';

        // 自动生成链接并填充到对应的输入框
        generateLink();
    }

    // 创建图片链接的函数
    function createImageUrl(text) {
        const encodedText = encodeURIComponent(text);
        return baseUrl + encodedText;
    }

    // 复制普通链接的函数
    function copyLink() {
        copyToClipboard('normalLink', "普通链接已复制！");
    }

    // 复制Markdown格式链接的函数
    function copyMarkdownLink() {
        copyToClipboard('markdownLink', "Markdown 链接已复制！");
    }

    // 复制到剪贴板的通用函数
    function copyToClipboard(elementId, message) {
        const element = document.getElementById(elementId);
        element.select();
        element.setSelectionRange(0, 99999); // 对于移动端
        document.execCommand('copy');
        showMessage(message);
    }

    // 显示消息提示
    function showMessage(message) {
        const messageBox = document.getElementById('message');
        messageBox.innerText = message;
        messageBox.style.display = 'block';
        setTimeout(() => {
            messageBox.style.display = 'none';
        }, 2000); // 2 秒后隐藏提示消息
    }
</script>

</body>
</html>
